package com.obj.studiopic.ad;

import android.app.Activity;
import android.content.Context;
import android.view.View;


import com.gdfdm.kybvx149211.AdCallbackListener;
import com.gdfdm.kybvx149211.AdView;
import com.gdfdm.kybvx149211.AirPlay;
import com.obj.studiopic.R;


public class AdAirpush  {
	private Context mContext;
	AirPlay airplay; //declare here
	public AdAirpush(Context mContext) {
		super();
		// TODO Auto-generated constructor stub
		this.mContext=mContext;

		if(airplay==null)
			airplay=new AirPlay((Activity) mContext, adCallbackListener, true);
	}
	/**
	 * ���������
	 */
	public void AdairpushRun(){
		AdView adView=(AdView)((Activity) mContext).findViewById(R.id.myAdview);
		adView.setAdListener(adlistener);
	}
	
	/**
	 *���� ��水���ؼ�����
	 */
	public void startappOnBackPressed(){
		if (airplay!=null) {
			airplay.startSmartWallAd();
		    }
	}
	

	AdCallbackListener adCallbackListener=new AdCallbackListener() {
        
        @Override
        public void onSDKIntegrationError(String message) {
        //Here you will receive message from SDK if it detects any integration issue.
        }

        public void onSmartWallAdShowing() {
        // This will be called by SDK when it��s showing any of the SmartWall ad.
        }

        @Override
        public void onSmartWallAdClosed() {
        // This will be called by SDK when the SmartWall ad is closed.
        }

        @Override
        public void onAdError(String message) {
        //This will get called if any error occurred during ad serving.
        }
        @Override
	public void onAdCached(AdType arg0) {
	//This will get called when an ad is cached. 
		
	}

		@Override
		public void onVideoAdFinished() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onVideoAdShowing() {
			// TODO Auto-generated method stub
			
		}
     };
	
	AdCallbackListener.MraidCallbackListener adlistener = new AdCallbackListener.MraidCallbackListener() {

		@Override
		public void onAdClickListener()
		{
			//This will get called when ad is clicked.
		}

		@Override
		public void onAdLoadedListener()
		{
			//This will get called when an ad has loaded.
		}

		@Override
		public void onAdLoadingListener()
		{
			//This will get called when a rich media ad is loading.
		}

		@Override
		public void onAdExpandedListner()
		{
			//This will get called when an ad is showing on a user's screen. This may cover the whole UI.
		}

		@Override
		public void onCloseListener()
		{
			//This will get called when an ad is closing/resizing from an expanded state.
		}

		@Override
		public void onErrorListener(String message)
		{
			//This will get called when any error has occurred. This will also get called if the SDK notices any integration mistakes.
		}
		@Override
		public void noAdAvailableListener() {
			//this will get called when ad is not available 

		}
	};
}
