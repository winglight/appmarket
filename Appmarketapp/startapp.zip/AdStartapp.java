package com.obj.studiopic.ad;

import android.app.Activity;
import android.content.Context;

import com.startapp.android.publish.StartAppAd;

public class AdStartapp {
	private Context mContext;
	private StartAppAd startAppAd;

	public AdStartapp(Context mContext) {
		super();
		// TODO Auto-generated constructor stub
		this.mContext=mContext;
		startAppAd = new StartAppAd(this.mContext); 
		StartAppAd.init(mContext, "xxxxxid", "xxxxxid");
	}

	/**
	 * �����ʾ
	 */
	public void adrun(){
		startAppAd.showAd();
		startAppAd.loadAd();
	}
	
	/**
	 * �����ͣ����
	 */
	public void startappOnPause(){
		 startAppAd.onPause(); 
	}
	/**
	 * ��水���ؼ�����
	 */
	public void startappOnBackPressed(){
		startAppAd.onBackPressed(); 
	}
	/**
	 * �����С���¿�ʼ����
	 */
	public void startappOnResume(){
		startAppAd.onResume();
	}
}
